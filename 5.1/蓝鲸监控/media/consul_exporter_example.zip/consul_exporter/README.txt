
## 1. 文件说明

├── README.txt // 压缩包说明
├── config_schema.json  // 定义运行prometheus exporter的配置项，如采集服务的访问方式（如redis账号）、metrics监听地址等;
├── description.md  // 组件采集的使用说明，便于后续新增组件实例时填写配置项，Markdown格式;
├── exporter  // 编译后的prometheus exporter（目前暂支持Linux），更多从https://prometheus.io/docs/instrumenting/exporters/获取;
├── info.json // 定义组件名，不可重名，需要提供name(必须)和display_name(可选)
├── logo.png // LOGO，区别其他组件，格式为PNG;
└── metrics.json  // 定义采集器的指标项，从/metrics中获取。

## 2. 温馨提示

为了安全起见，强烈建议将Prometheus Exporter的HTTP API监听在127.0.0.1，蓝鲸的采集器会从本机获取metrics(指标)加密传输以防止metrics泄露。


